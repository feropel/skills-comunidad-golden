# Changelog · golden-cobros

## v1.0.1 — 2026-08-03 · correcciones de auditoría (golden-skill-auditor: 865→objetivo ORO)
Arreglados los 2 críticos + el intruso del informe `AUDITORIAS-SKILLS/2026-08-03-golden-cobros.md`:
- **Datos personales fuera de la skill:** fixtures de `evals/` anonimizados (correos ficticios
  a*/x*/m*/d*@fixture.test que conservan la topología 14/12/2/4/0); nombres y deudas reales
  retirados de SKILL.md, CHANGELOG y `conciliacion.md`. Los datos reales viven en las pasarelas y
  en el chat, jamás aquí.
- **Identificadores privados a punteros:** el acct de Stripe, el project de Supabase y el banco de
  payout salieron de los archivos y viven en `~/.golden/golden-cobros.env`; la skill los referencia
  como `$STRIPE_ACCT` / `$SUPABASE_PROJECT` / `$PAYOUT_BANCO`. Añadido banner **LOCAL — NO
  DISTRIBUIBLE** en el encabezado.
- **Cola de prioridad sin mezclar monedas:** `consolidar.py` ahora agrupa por moneda y ordena
  dentro de cada una (COP y USD nunca se comparan entre sí — eso sería convertir).
- Revalidado con el fixture anonimizado: 12/2/4/0, idéntico.

## v1.0.0 — 2026-08-03 (fábrica: chat PASARELA DE PAGOS)
Primera versión. Fabricada por asignación del Centro de Mando (delegación de FER), en el chat con
el dolor diario de cobros.

- **SKILL.md**: recuperación de cartera cruzando Stripe (USD, live) + Mercado Pago (COP). Filosofía
  "recomienda, no ejecuta". Las 6 reglas duras (verificar en ambas pasarelas el mismo día, ojo al
  pago cruzado, no crear enlaces, montos de consulta en vivo, nunca convertir moneda, informe solo
  de su tema). Flujo de 7 pasos y entregable fijo de 4 partes.
- **references/pasarelas.md**: cómo jalar Stripe (MCP lectura → base del webhook Supabase → dashboard
  por navegador) y Mercado Pago (`mp.py` + `cache_pagos.py`, token referenciado de `~/.golden`),
  con respaldos ante caídas y los límites reales (MP no da celular ni saldo).
- **references/conciliacion.md**: conceptos normalizados (total/anticipo/abono/reserva), reglas de
  estado (completo / debe 2ª mitad / debe saldo reserva), la regla del PAGO CRUZADO, duplicados y
  prioridad por monto + antigüedad. Sin conversión de moneda.
- **references/mensajes.md**: 5 plantillas de cobro estilo Golden (sin signos de apertura), con el
  link SIEMPRE de los existentes.
- **scripts/consolidar.py**: agrupa por correo, marca cruces y duplicados, suma por moneda y sugiere
  estado — sin convertir moneda. Solo lectura.
- **Prueba real (topología del día 2026-08-02, fixture anonimizado):** 14 clientes MBA →
  12 completos, 2 deudores ($1.800.000 y $1.300.000 COP), 4 pagos cruzados detectados, 0 falsos
  duplicados. Coincide al 100% con la conciliación manual. Los correos/nombres reales NO se
  guardan en la skill. ✅
- Cero credenciales horneadas: `mp.py`, token y MCPs se referencian por ruta.
