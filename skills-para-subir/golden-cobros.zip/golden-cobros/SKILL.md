---
name: golden-cobros
description: >-
  Golden Group — RECUPERACIÓN DE CARTERA de la Comunidad Golden (MBA, VIP, asesorías, servicios). Consolida la deuda VIVA cruzando las DOS pasarelas (Stripe en vivo + Mercado Pago), arma el estado de cuenta por cliente/alumno, DETECTA pagos cruzados (pagó en una pasarela lo que debía en la otra) y genera la COLA DE COBROS del día con el mensaje exacto por cliente, priorizada por monto y antigüedad. Recomienda y reporta; NUNCA ejecuta cobros, mueve plata ni crea enlaces de pago. Úsala SIEMPRE que el usuario quiera: revisar la cartera, "quién me debe", "cobros del día", "estado de cuenta MBA", "cierre quincenal VIP", "verifica la deuda en las dos pasarelas", "quién pagó / conciliar Stripe y Mercado Pago", saber cuánto falta por cobrar, quién se atrasó, o suba un export de pagos de cualquiera de las dos pasarelas. Dispara aunque no diga "cartera": basta con deuda pendiente, morosos, conciliación entre Stripe y Mercado Pago, o armar la secuencia de cobro. NO es el webhook stripe-pago (que solo REGISTRA pagos entrantes) ni crea/gestiona enlaces de pago (eso se hace a mano con los links que YA existen); tampoco es análisis de pauta (golden-ads) ni de logística Dropi.
---

# golden-cobros · recuperación de cartera de la Comunidad Golden

> ⚠️ **SKILL LOCAL — NO DISTRIBUIBLE.** Opera sobre el entorno vivo de Golden (Stripe live,
> Mercado Pago, Supabase). Los identificadores concretos del entorno viven en
> `~/.golden/golden-cobros.env` y las credenciales en `~/.golden` — **nada de eso se hornea aquí**.
> No compartir esta skill fuera del equipo Golden.

Esta skill es el **cobrador** de Golden. Toma las dos pasarelas donde entra la plata
—**Stripe** (en vivo, pago anticipado en USD) y **Mercado Pago** (COP)— y responde la
pregunta que se hace todos los días: **quién me debe, cuánto, desde cuándo, y qué le escribo
para cobrarle.** El dolor real es que un mismo alumno paga la mitad en una pasarela y la otra
mitad en la otra, así que la deuda no se ve completa en ninguna de las dos por separado.

**Filosofía innegociable: esta skill RECOMIENDA, no ejecuta.** No cobra, no mueve plata, no
hace reembolsos, no crea ni activa enlaces de pago. Entrega el estado de cuenta y la cola de
cobros con el texto listo; **quien aprieta el botón es FER**, a mano, con los links que ya
existen. Esa frontera protege la plata y es una regla dura de la casa.

## Las 6 reglas duras (de memoria, verificadas — nunca las rompas)

1. **Verifica la deuda en las DOS pasarelas el MISMO día en que se va a cobrar.** El saldo se
   mueve solo: un alumno completa en Stripe mientras se redacta el cobro en Mercado Pago. Ya
   pasó de verdad — casi se doble-cobra. Consulta en vivo, no confíes en una lista de ayer.
2. **Ojo al PAGO CRUZADO.** Si pagó en una pasarela lo que debía en la otra, **NO está en mora**:
   está completo. Recobrarle es el peor error que puede cometer esta skill.
3. **NO crear más enlaces de pago** (ni Stripe ni Mercado Pago). El cobro se hace con los links
   que ya existen. Esta skill jamás propone crear uno nuevo.
4. **Los montos SIEMPRE salen de consultar la pasarela en vivo, jamás inventados.** Si una
   pasarela no responde, se dice "pendiente de verificar", no se estima.
5. **Nunca convertir moneda.** Cada canal en su moneda (Stripe USD, Mercado Pago COP). La tasa
   se mueve demasiado; mezclar monedas descuadra el informe. Se reportan los dos totales por
   separado.
6. **Un informe de cartera habla solo de lo que se pidió** (MBA, VIP, etc.). Nada de otras
   transacciones ni de información no pedida. Mercado Pago también recibe compras de la tienda
   Shopify ("Compra en Golden Group Enterprise" / "DOLCE INCANTO") — esas NO son MBA; filtra por
   el concepto que corresponda.

## El flujo (de punta a punta)

1. **Define el alcance.** Qué cartera se revisa: MBA (lo más común), VIP, asesorías, o todo.
   Eso decide por qué concepto filtrar en cada pasarela.
2. **Jala Stripe (en vivo).** Pagos exitosos del período. Cómo, con qué tools y qué hacer si el
   panel se cae → `references/pasarelas.md`.
3. **Jala Mercado Pago (en vivo).** Con `mp.py` / `cache_pagos.py` de la carpeta MERCADOPAGO.
   Ídem → `references/pasarelas.md`.
4. **Consolida y cruza.** Agrupa por correo del cliente, junta lo pagado en cada pasarela,
   detecta cruces y posibles duplicados. Hay un script que hace la parte mecánica:
   `scripts/consolidar.py` (ver abajo).
5. **Aplica el estado de cada cliente** según su plan (pago total, 2 abonos, reserva) →
   `references/conciliacion.md`. Aquí decides quién está completo y quién debe, y cuánto,
   **en su moneda**.
6. **Arma la cola de cobros** con el mensaje exacto por cliente, priorizada por monto y
   antigüedad → plantillas en `references/mensajes.md`.
7. **Entrega el informe** con el formato de abajo.

## Datos: de dónde salen (resumen; detalle en references/pasarelas.md)

- **Stripe** — cuenta live (el `acct` está en `~/.golden/golden-cobros.env`, no aquí). Fuente primaria: **MCP de Stripe en modo
  lectura** (charges / payment_intents / invoices / payment_links / disputes). Se desconecta a
  veces; si no responde, hay respaldo por navegador (dashboard) y por la base del webhook
  (`pagos_servicios` en Supabase, que registra cada pago exitoso). El detalle por pago (nombre,
  celular, país, comisión exacta) vive en la página del pago; el panel se pone lento — abrir un
  **navegador nuevo** suele destrabarlo.
- **Mercado Pago** — cuenta MCO. **El MCP oficial de MP NO sirve** para consultar ventas. Se usa
  `PROYECTOS/MERCADOPAGO/mp.py` (SOLO LECTURA) con el token en `~/.golden/mercadopago.env`. El
  token y el script se **REFERENCIAN**, jamás se copian dentro de la skill. `cache_pagos.py N`
  baja todas las operaciones a `todos_pagos.json` — úsalo antes de afirmar que algo "no existe".
  Límite: **MP no expone el celular del comprador ni el saldo disponible** (ese saldo solo lo ve
  FER con su clave). Fallback si el API/DNS falla: leer `mercadopago.com.co/activities` por
  navegador (sin clave).

Credenciales: NUNCA leerlas ni imprimirlas en el chat. Se referencian de `~/.golden`; el script
`mp.py` y el token viven fuera de la skill y se invocan por su ruta, jamás se copian aquí dentro
(regla de golden-blindaje / el hook Golden Careful).

## Consolidar y cruzar (scripts/consolidar.py)

La parte mecánica —agrupar por correo, sumar por pasarela, marcar cruces y duplicados— la hace
un script para no reinventarla cada vez y para no equivocarse a mano:

```bash
python3 ~/.claude/skills/golden-cobros/scripts/consolidar.py stripe.json mp.json --out consolidado.json
```

- **Entradas:** dos JSON que TÚ armas al jalar cada pasarela. Formato exacto (campos, ejemplo)
  en la cabecera del script y en `references/conciliacion.md`. Cada pago: `email`, `monto`,
  `moneda`, `fecha`, `concepto`, `estado`.
- **Salida:** por cada correo, lo pagado en Stripe y en MP, banderas de **CRUCE** (aparece en
  las dos) y **posible duplicado**, y los totales por moneda. El script **no decide la mora**:
  eso lo aplicas tú con las reglas de plan de `references/conciliacion.md`, porque el "cuánto
  debe" depende del plan (total vs 2 abonos vs reserva) y jamás se convierte moneda.

Si el script no aplica (poquísimos clientes, o datos que no encajan en el formato), consolida a
mano siguiendo `references/conciliacion.md`. El script es una ayuda, no una obligación.

## Entregable (formato fijo)

Entrega SIEMPRE estas cuatro partes, en este orden:

1. **Estado de cuenta consolidado por cliente** — tabla: cliente (correo), estatus en Stripe,
   estatus en Mercado Pago, estado final (completo / debe / cruce), saldo pendiente **en su
   moneda**, antigüedad (días desde el último pago o desde el anticipo).
2. **Pagos cruzados / duplicados a conciliar** — quién pagó en las dos pasarelas (y por tanto
   NO debe), y cualquier posible pago doble que amerite revisar o devolver.
3. **Cola de cobros del día** — solo los que SÍ deben, priorizados por monto y antigüedad, cada
   uno con su **mensaje listo para copiar** (texto de `references/mensajes.md`, en la moneda del
   cliente). Recuerda: el link es uno EXISTENTE; si no hay link para ese caso, dilo, no inventes.
4. **Resumen** — facturado / cobrado / pendiente, por pasarela y en su moneda, y —si aplica— la
   meta del **cierre quincenal VIP**. Nunca un total combinado convertido.

Cuando el dato fino no se pudo verificar (pasarela caída, celular que MP no guarda), **dilo
explícito** en el informe; no lo estimes ni lo dejes en blanco silencioso.

## Modo prueba

Por defecto esta skill trabaja en **modo informe**: consulta (lectura) y entrega el reporte, sin
tocar ninguna pasarela. No hay un "modo ejecución": cobrar y crear links es siempre manual de
FER. Si te piden "cobra", aclara que tú preparas la cola y el mensaje, y que el cobro lo cierra
FER a mano con el link existente.

## Frontera con el webhook stripe-pago (no lo dupliques)

El webhook `stripe-pago` (edge function en Supabase) solo **REGISTRA** los pagos entrantes y
avisa por correo. **Esta skill es la capa de RECUPERACIÓN**: lee lo que hay, concilia entre
pasarelas y arma la secuencia de cobro. No toca el webhook, no reimplementa el registro. Si algo
huele a "modificar cómo se registran los pagos", eso es del webhook, no de esta skill.

## Contexto vivo (verifícalo, no lo des por fijo)

Orden de magnitud al arrancar la skill: el MBA tiene una decena de cobros en curso, la deuda viva
suele ser de unos pocos millones de COP repartidos en 1-3 alumnos, y hay un **cierre quincenal
VIP**. Estos números CAMBIAN a diario y los alumnos concretos NO se listan aquí (viven en la
consulta en vivo y en el chat de PASARELA DE PAGOS). **Siempre** re-consulta las dos pasarelas
antes de reportar; jamás cobres desde una cifra escrita en esta skill. El catálogo de links vivos
y los precios por fecha del MBA están en `PROYECTOS/COMUNIDAD-GOLDEN-PAGOS/LINKS-DE-PAGO-STRIPE.md`
(el precio del MBA sube por fechas: un monto distinto entre alumnos NO es un error).
