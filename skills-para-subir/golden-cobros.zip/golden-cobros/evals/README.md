# Fixture de regresión — topología del flujo MBA real (anonimizada)
14 clientes ficticios (a*, x*, m*, d* @fixture.test) que reproducen la MISMA estructura del día
real, sin datos personales. Esperado al correr consolidar.py sobre los dos JSON:
- 12 completos, 2 deudores ($1.800.000 y $1.300.000 COP), 4 pagos cruzados (x1–x4), 0 duplicados.
Comando: `python3 ../scripts/consolidar.py fixture_stripe_2026-08-02.json fixture_mp_2026-08-02.json --out /tmp/c.json`
Los datos reales viven en las pasarelas y en el chat PASARELA DE PAGOS, nunca en la skill.
