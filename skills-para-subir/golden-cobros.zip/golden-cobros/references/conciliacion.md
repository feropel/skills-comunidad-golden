# Conciliación: quién está completo, quién debe, y cuánto

El script agrupa y marca cruces/duplicados. **El estado de mora lo decides tú** con estas reglas,
porque el "cuánto debe" depende del plan y **jamás se convierte moneda**.

## Conceptos normalizados

Al armar los JSON, mapea la descripción real de cada pasarela a uno de estos 4 conceptos:

| Concepto | Qué significa | Descripciones reales que lo disparan |
|---|---|---|
| `total` | Pagó el 100% de una vez | "MBA", "MBA (pago total)", "Pago total" |
| `anticipo` | Primera mitad (50%) | "MBA ANTICIPO 50%", "Anticipo 50%" |
| `abono` | Una mitad (1ª o 2ª), típico de Stripe | "Abono 50% (1 de 2)", "abono", "2do Abono" |
| `reserva` | Apartó cupo con un monto parcial menor al 50% | "Reserva de cupo", "MBA – Reserva de Cupo" |

`anticipo` y `abono` son ambos "mitades" para efectos de completar. La diferencia es histórica
(MP suele decir "anticipo", Stripe "abono").

## Reglas de estado (MBA — el caso principal)

Para cada cliente, junta TODOS sus pagos aprobados de las dos pasarelas y aplica:

- **Completo** si: tiene un `total`, **o** suma **2 mitades** (`anticipo`/`abono`, en cualquier
  combinación de pasarelas — aquí es donde vive el PAGO CRUZADO), **o** un `anticipo`/`abono` +
  otro `abono` que lo complete.
- **Debe la 2ª mitad** si: tiene **1 sola mitad** y nada más. El saldo = **el mismo monto de la
  mitad que pagó, en su misma moneda** (si pagó $1.300.000 COP de anticipo, debe $1.300.000 COP;
  si pagó US$399,99 de abono, debe US$399,99). No se convierte.
- **Debe saldo de reserva** si: solo tiene una `reserva`. El saldo = precio total − reserva, en
  la moneda de la reserva. Para MBA en COP el total de referencia es **$2.600.000** (reserva de
  $800.000 → debe $1.800.000). Verifica el total vigente; el precio del MBA **sube por fechas**.

## PAGO CRUZADO — la regla que más plata protege

Un cliente que aparece en **las dos pasarelas** casi siempre pagó mitad en cada una → **está
completo, NO debe**. Ejemplo real: anticipo de $1.300.000 en Mercado Pago + abono de US$399,99 en
Stripe = MBA cubierto. El script lo marca con la bandera `cruce`. **Antes de poner a alguien en la
cola de cobros, confirma que no tenga un pago en la OTRA pasarela** que ya lo complete. Recobrar a
un cruzado es el peor error posible.

Nota de moneda en los cruces: las dos mitades están en monedas distintas (una COP, otra USD) y los
precios por canal no son idénticos. **No intentes cuadrar el cruce al centavo convirtiendo** — si
cada quien puso "una mitad" en su canal según lo que se le cotizó, está completo. Si hay una
diferencia real de plan, márcala como nota para que FER decida, no la resuelvas convirtiendo.

## Duplicados / sobrepagos

El script marca `posible_duplicado` cuando un mismo correo tiene más pagos de los que su plan
necesita (p.ej. 3 mitades, o 2 `total`). Revísalo: puede ser un sobrepago que amerite **devolución**
(eso lo decide FER; la skill solo lo señala). No lo cuentes como "avance", sepáralo.

## Antigüedad y prioridad

- **Antigüedad** = días desde el último pago del cliente (para reserva/anticipo pendiente, desde
  ese pago). Entre más viejo, más frío el lead y más urge.
- **Prioridad de la cola** = **dentro de cada moneda** (los saldos COP y USD NO se comparan entre
  sí — compararlos sería convertir), primero por **monto adeudado** (lo grande primero) y a
  igualdad, por **antigüedad** (lo más viejo primero). El script agrupa por moneda y ordena así.

## Formato de entrada del script (recordatorio)

Dos JSON (uno por pasarela), lista de objetos:
```json
{"email": "alumno@ejemplo.test", "monto": 1300000, "moneda": "COP",
 "fecha": "2026-07-17", "concepto": "anticipo", "estado": "aprobado"}
```
- Solo aprobados. `monto` en unidad natural (USD decimal, COP entero). `concepto` de la tabla de
  arriba. `email` en minúsculas.
