# Plantillas de mensaje de cobro (listas para copiar)

Reglas de estilo Golden para estos textos:
- **Sin signos de apertura** `¿` ni `¡` (solo el de cierre). Suena más humano.
- Tono cálido, directo, respetuoso; nunca agresivo ni culposo. Se cobra con cariño y firmeza.
- **En la moneda del cliente**, con el monto exacto que arrojó la conciliación.
- **El link es uno que YA existe** (del catálogo `LINKS-DE-PAGO-STRIPE.md` o el que FER tenga en
  Mercado Pago). Si no hay link para ese caso, escribe `[link — lo pasa FER]` y dilo en el
  informe; **nunca inventes una URL ni propongas crear un link nuevo**.
- Rellena `[Nombre]` con el nombre real si lo tienes (Stripe lo trae; MP no siempre). Si no, usa
  un saludo neutro.
- Ajusta canal: casi todo se envía por **WhatsApp** (la comunidad es WhatsApp-first).

## 1 · Debe la segunda mitad (anticipo/abono pendiente)

> Hola [Nombre], te escribo del equipo de Golden. Tu primer pago del MBA quedó registrado el
> [fecha], ya tienes la mitad cubierta. Para cerrar tu cupo falta la segunda mitad, que son
> [MONTO en su moneda]. Te la cobramos en [pesos/dólares], igual que el primer pago. Me confirmas
> y te paso el link para completar.

## 2 · Debe saldo tras reserva de cupo

> Hola [Nombre], gracias por reservar tu cupo del MBA el [fecha] con los [MONTO reserva]. Para
> activarlo completo falta el saldo de [MONTO saldo]. Me confirmas y te paso el link. Si prefieres
> partirlo en dos, dime y lo acomodamos.

## 3 · Recordatorio suave (2º toque, si no respondió al primero)

> Hola [Nombre], te recuerdo que tu cupo del MBA queda apartado en cuanto completes [MONTO]. No
> quiero que pierdas el lugar. Cualquier duda con el pago me dices y lo resolvemos.

## 4 · Confirmación a un CRUZADO (no es cobro — es cierre)

Cuando alguien completó pagando en las dos pasarelas, NO se le cobra: se le confirma. Útil para
cerrar y evitar que él mismo pague de más.

> Hola [Nombre], confirmado: tu MBA quedó pagado al 100%. Registramos tu pago en [pasarela A] y el
> segundo en [pasarela B]. No tienes nada pendiente. Bienvenido, cualquier cosa aquí estoy.

## 5 · Aviso interno a FER (no al cliente) para un posible duplicado / devolución

> OJO FER: [correo] tiene un posible pago doble — [detalle: montos, pasarelas, fechas]. No es
> deuda; puede ser sobrepago a revisar o devolver. Decisión tuya; yo no toco reembolsos.

## Cómo van en la cola

Cada cliente de la cola de cobros del día se entrega así:
```
[prioridad]. [correo] — debe [MONTO en su moneda] (antigüedad: [N] días, [pasarela del anticipo])
   Mensaje: «[texto de la plantilla que aplique, ya rellenado]»
   Link: [uno EXISTENTE, o "lo pasa FER"]
```
