# Cómo jalar cada pasarela (en vivo) — con respaldos

Regla madre: el dato sale de consultar la pasarela **hoy**. Si una fuente falla, se pasa a la
siguiente; si ninguna responde, se reporta "pendiente de verificar", nunca se estima.

Identificadores del entorno (acct de Stripe, project de Supabase, banco de payout): en
`~/.golden/golden-cobros.env`. Cárgalos de ahí; abajo se escriben como `$STRIPE_ACCT`, etc.

## STRIPE (USD, cuenta live — `$STRIPE_ACCT` en ~/.golden/golden-cobros.env)

### Fuente 1 — MCP de Stripe (lectura). Preferida.
Tools de lectura del MCP de Stripe (nombres `stripe_api_read` / `stripe_api_search`, o las
tools con prefijo del servidor de Stripe conectado). Operaciones útiles:
- Pagos exitosos del período: listar `charges` o `payment_intents` (estado succeeded).
- `payment_links` para saber por qué link entró cada pago (identifica el concepto/precio).
- `invoices` y `disputes` si aplica (contracargos abiertos = plata en riesgo).
Por cada pago necesitas: correo del cliente, monto (bruto), moneda, fecha, y el concepto
(por el payment_link o la descripción). Para el neto y la comisión exacta, el `balance_transaction`
del charge.

**El MCP de Stripe se desconecta a veces.** Si las tools no están, cárgalas con ToolSearch; si el
servidor está caído, pasa a la Fuente 2.

### Fuente 2 — Base del webhook (Supabase). Respaldo sólido y siempre disponible.
El webhook `stripe-pago` registra cada pago exitoso en la tabla **`pagos_servicios`** del proyecto
Supabase (`$SUPABASE_PROJECT` de ~/.golden/golden-cobros.env). Consulta por MCP de Supabase:
```sql
select email, amount, tipo, payment_link, paid_at
from pagos_servicios
where tipo = 'mba'          -- o el rubro que corresponda
order by paid_at;
```
`amount` está en **centavos de USD** (39999 = US$399,99; 79900 = US$799). Esta base responde
aunque el dashboard de Stripe esté degradado. NO trae comisión ni datos de cliente (nombre/celular).

### Fuente 3 — Dashboard por navegador. Para el detalle fino.
`dashboard.stripe.com/$STRIPE_ACCT/payments` — lista de pagos. El detalle de cada pago
(`/payments/pi_...`) trae nombre, celular, país (campo "País desde donde te conectas"), y el
desglose bruto/comisión/neto exacto. Transferencias al banco: `/payouts` (la cuenta bancaria
configurada, `$PAYOUT_BANCO`) — OJO: los payouts son del saldo de la cuenta COMPLETA, no
separables por producto.
- El panel se pone **lento/degradado**. Trucos que funcionan: abrir un **navegador nuevo** (a
  veces la sesión vieja es la que falla), y esperar 8-15 s por página; leer con `get_page_text`
  antes que screenshot. Si sale "Estamos investigando un problema", es un incidente de Stripe:
  reintentar más tarde, no forzar.

### Comisión de Stripe (para el neto)
Observada real en esta cuenta: efectiva ≈ **4,46%** (por tramo: 4,48% en los cargos de US$399,99
→ comisión US$17,90, neto US$382,09; 4,44% en los de US$799 → comisión US$35,46, neto US$763,54).
Igual, el dato exacto por cargo sale del `balance_transaction`; usa el % solo como referencia si
el detalle no está disponible, y dilo.

## MERCADO PAGO (COP, cuenta MCO)

### El MCP oficial de Mercado Pago NO sirve (es para desarrollo). Se usa el script local.
Carpeta: `PROYECTOS/MERCADOPAGO/`. Token en `~/.golden/mercadopago.env` (chmod 600). El token y el
script se **referencian**, jamás se copian a la skill ni se imprimen en el chat.

```bash
cd "<...>/PROYECTOS/MERCADOPAGO"
python3 mp.py ping                 # valida credencial
python3 mp.py pagos 30 --csv       # pagos de N días (+ CSV)
python3 mp.py buscar MBA 30        # por texto en la descripción
python3 cache_pagos.py 30          # baja TODAS las operaciones (con pagador) a todos_pagos.json
```

**Usa `cache_pagos.py` antes de afirmar que algo no existe** — `buscar` por texto se queda corto.
El cache guarda por operación: `fecha`, `fecha_aprobado`, `estado` (approved/rejected), `bruto`,
`neto`, `moneda`, `descripcion`, `email`, `nombre` (titular de la tarjeta), `doc`, `ult4`.

Leer el cache (claves en español):
```python
import json
ops = json.load(open("todos_pagos.json"))
for o in ops:
    if o["estado"] == "approved" and "MBA" in (o.get("descripcion") or ""):
        print(o["fecha"][:10], o["bruto"], o["descripcion"], o["email"])
```

### Límites de Mercado Pago (dilo en el informe, no lo pelees)
- **No expone el celular del comprador** (el checkout no lo capturó). El `nombre` disponible es el
  **titular de la tarjeta**, que puede no ser el alumno. País: se infiere Colombia si la tarjeta
  es COL y el pago en COP.
- **No da el saldo disponible** por API (403). Ese dato solo lo lee FER en el panel con su clave.
- Comisión MP observada ≈ **5,82%** ($1.300.000 → neto $1.224.168, comisión $75.832).
- Fallback si el API/DNS falla: leer `mercadopago.com.co/activities` por navegador (sin clave;
  muestra fecha, concepto, monto, estado). El detalle de una operación por API completa se saca
  con `mp.py detalle <id>` o pegándole al endpoint `/v1/payments/<id>` con el token (importando
  `mp.cargar_token()`), no copiando el token.

## Armar los JSON para consolidar

Al terminar de jalar cada pasarela, arma dos listas con este formato (una por pasarela) y pásalas
a `scripts/consolidar.py`:
```json
[
  {"email": "cliente@correo.com", "monto": 399.99, "moneda": "USD",
   "fecha": "2026-07-31", "concepto": "abono", "estado": "aprobado"}
]
```
- `monto` en la unidad natural de la moneda (USD con decimales; COP entero).
- `concepto` normalizado a una de: `total`, `abono`, `anticipo`, `reserva` (ver conciliacion.md).
- Solo pagos **aprobados/exitosos** (los rechazados no son deuda ni pago).
