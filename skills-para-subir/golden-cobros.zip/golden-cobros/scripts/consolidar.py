#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
golden-cobros · consolidar.py  (SOLO LECTURA — no toca pasarelas)

Agrupa por correo los pagos de las dos pasarelas, marca PAGOS CRUZADOS (mismo
cliente en Stripe y en Mercado Pago) y POSIBLES DUPLICADOS, suma por moneda y
propone un estado — SIN convertir moneda jamás. El estado es SUGERIDO: la
palabra final la da quien corre la skill aplicando references/conciliacion.md.

Uso:
    python3 consolidar.py stripe.json mp.json --out consolidado.json
    python3 consolidar.py stripe.json mp.json --precio-total-cop 2600000

Cada JSON de entrada es una LISTA de pagos APROBADOS con estos campos:
    {"email":"c@x.com","monto":399.99,"moneda":"USD",
     "fecha":"2026-07-31","concepto":"abono","estado":"aprobado"}
- monto: unidad natural (USD con decimales, COP entero).
- concepto: uno de  total | anticipo | abono | reserva  (ver conciliacion.md).
- El primer archivo se etiqueta pasarela "Stripe", el segundo "Mercado Pago"
  (o pásalos como quieras; se toman por posición).
"""
import argparse, json, sys, math
from datetime import date

MITAD = {"anticipo", "abono"}


def cargar(path):
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, list):
        sys.exit(f"{path}: se esperaba una lista de pagos.")
    return data


def dias_desde(fecha_str):
    try:
        y, m, d = map(int, fecha_str[:10].split("-"))
        return (date.today() - date(y, m, d)).days
    except Exception:
        return None


def money(monto, moneda):
    if moneda == "USD":
        return f"US${monto:,.2f}"
    if moneda == "COP":
        return f"${monto:,.0f}"
    return f"{monto} {moneda}"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("stripe_json")
    ap.add_argument("mp_json")
    ap.add_argument("--out", default="consolidado.json")
    ap.add_argument("--precio-total-cop", type=float, default=2600000,
                    help="Precio total del MBA en COP para calcular saldo de reserva (verificar vigente).")
    a = ap.parse_args()

    fuentes = [("Stripe", a.stripe_json), ("Mercado Pago", a.mp_json)]
    clientes = {}
    for pasarela, path in fuentes:
        for p in cargar(path):
            if (p.get("estado") or "").lower() not in ("aprobado", "approved", "exitoso", "succeeded", "paid", ""):
                continue
            email = (p.get("email") or "").strip().lower()
            if not email:
                continue
            c = clientes.setdefault(email, {"email": email, "pagos": []})
            c["pagos"].append({
                "pasarela": pasarela,
                "monto": p.get("monto"),
                "moneda": p.get("moneda"),
                "fecha": (p.get("fecha") or "")[:10],
                "concepto": (p.get("concepto") or "").lower().strip(),
            })

    filas = []
    for email, c in clientes.items():
        pagos = c["pagos"]
        pasarelas = {x["pasarela"] for x in pagos}
        conceptos = [x["concepto"] for x in pagos]
        n_total = sum(1 for k in conceptos if k == "total")
        n_mitad = sum(1 for k in conceptos if k in MITAD)
        n_reserva = sum(1 for k in conceptos if k == "reserva")
        cruce = len(pasarelas) >= 2

        # sumas por moneda (NUNCA se convierten)
        sumas = {}
        for x in pagos:
            sumas[x["moneda"]] = sumas.get(x["moneda"], 0) + (x["monto"] or 0)

        # estado sugerido + saldo (en la moneda del pago pendiente)
        estado, saldo, saldo_mon = "revisar", None, None
        if n_total >= 1 or n_mitad >= 2:
            estado = "completo"
        elif n_mitad == 1:
            estado = "debe 2a mitad"
            m = next(x for x in pagos if x["concepto"] in MITAD)
            saldo, saldo_mon = m["monto"], m["moneda"]
        elif n_reserva >= 1:
            estado = "debe saldo reserva"
            r = next(x for x in pagos if x["concepto"] == "reserva")
            if r["moneda"] == "COP":
                saldo, saldo_mon = a.precio_total_cop - (r["monto"] or 0), "COP"
            else:
                saldo, saldo_mon = None, r["moneda"]  # total en otra moneda: calcular a mano

        # posible duplicado / sobrepago: más pagos de los que un cupo necesita
        cupos = n_total + math.ceil(n_mitad / 2) + (1 if (n_reserva and not n_mitad and not n_total) else 0)
        posible_duplicado = n_total >= 2 or n_mitad >= 3 or (n_total >= 1 and n_mitad >= 1)

        antig = min([dias_desde(x["fecha"]) for x in pagos if dias_desde(x["fecha"]) is not None] or [None]) \
            if estado == "completo" else \
            max([dias_desde(x["fecha"]) for x in pagos if dias_desde(x["fecha"]) is not None] or [None])

        filas.append({
            "email": email,
            "pasarelas": sorted(pasarelas),
            "cruce": cruce,
            "estado_sugerido": estado,
            "saldo": saldo, "saldo_moneda": saldo_mon,
            "saldo_fmt": money(saldo, saldo_mon) if saldo is not None else None,
            "antiguedad_dias": antig,
            "posible_duplicado": posible_duplicado,
            "pagos": pagos,
            "sumas": {k: money(v, k) for k, v in sumas.items()},
        })

    # orden: primero los que deben; agrupados POR MONEDA (nunca se comparan montos de monedas
    # distintas — eso sería convertir); dentro de cada moneda, por monto desc y luego antigüedad desc.
    def clave(f):
        debe = f["estado_sugerido"].startswith("debe")
        return (0 if debe else 1, f["saldo_moneda"] or "", -(f["saldo"] or 0), -(f["antiguedad_dias"] or 0))
    filas.sort(key=clave)

    with open(a.out, "w", encoding="utf-8") as f:
        json.dump(filas, f, ensure_ascii=False, indent=2)

    # resumen a stdout (markdown)
    deben = [f for f in filas if f["estado_sugerido"].startswith("debe")]
    cruces = [f for f in filas if f["cruce"]]
    dups = [f for f in filas if f["posible_duplicado"]]
    print(f"# Consolidado — {len(filas)} clientes\n")
    print(f"- Completos: {sum(1 for f in filas if f['estado_sugerido']=='completo')}")
    print(f"- Deben (sugerido): {len(deben)}")
    print(f"- Pagos cruzados (2 pasarelas): {len(cruces)}")
    print(f"- Posibles duplicados a revisar: {len(dups)}\n")
    if deben:
        print("## Cola de cobros sugerida (verificar en vivo antes de enviar)\n")
        print("| # | Cliente | Debe | Antigüedad | Estado |")
        print("|---|---|---|---|---|")
        for i, f in enumerate(deben, 1):
            print(f"| {i} | {f['email']} | {f['saldo_fmt'] or 'calcular'} | {f['antiguedad_dias']} d | {f['estado_sugerido']} |")
    if cruces:
        print("\n## Cruces detectados (NO cobrar — verificar que estén completos)")
        for f in cruces:
            print(f"- {f['email']} · {', '.join(f['pasarelas'])} · {f['estado_sugerido']}")
    if dups:
        print("\n## Posibles duplicados / sobrepagos (avisar a FER, no contar como avance)")
        for f in dups:
            print(f"- {f['email']} · {f['sumas']}")
    print(f"\nDetalle completo → {a.out}")
    print("Recuerda: estado SUGERIDO. Verifica en vivo, no conviertas moneda, no crees links.")


if __name__ == "__main__":
    main()
