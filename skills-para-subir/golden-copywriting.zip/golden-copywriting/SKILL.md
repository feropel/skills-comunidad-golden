---
name: golden-copywriting
description: >-
  Golden Group — Copywriting de respuesta directa para TODOS los canales: anuncios
  de Meta (Facebook/Instagram), TikTok Ads, y mensajes orgánicos para WhatsApp,
  Facebook e Instagram. Escribe hooks, primary text, headlines, descripciones,
  guiones de video (UGC/TikTok), captions y secuencias de mensajes, con ángulos
  de venta, frameworks probados (AIDA, PAS, BAB, 4U) y tono LatAm que convierte tanto en
  contra entrega como en pago anticipado.
  Úsala SIEMPRE que el usuario quiera: escribir/mejorar copy de anuncios, hooks,
  textos para Meta o TikTok, guiones de reels/UGC, captions para redes, mensajes
  de WhatsApp/orgánicos, "hazme el copy de", "dame ángulos de venta", "ganchos
  para este producto", "textos para vender X". Aplica a cualquier producto/país.
  Trae el estándar MEDIDO de largos de Meta (125/40/25, rendimiento bimodal, la ventana
  visible de 125 caracteres) y una bitácora de tendencias que se refresca cada 8 días con
  el mercado y con las campañas reales, así que úsala también para "cuántos caracteres
  debe tener", "qué copy está funcionando ahora", "qué está vendiendo en el mercado".
  Para el PROMPT del bot de ventas usa golden-chatea-pro-prompt-ventas.
---

# Golden Group — Copywriting Multicanal

**Versión:** `GCW1.3.3` · **Fábrica: el CENTRO DE MANDO** (chat "🧠 GOLDEN - CENTRO DE MANDO - NO BORRAR").

> 🏭 **Quién puede editar esta skill.** No tiene chat-fábrica propio, y por la regla de la casa
> *skill sin chat-fábrica = su fábrica es el Centro de Mando*. Manos autorizadas, solo dos:
> el **Centro de Mando**, y la tarea **`copywriting-tendencias-8-dias`** como **brazo delegado**
> —la única mano automática que puede escribir aquí, siempre con el ritual completo y dejando
> parte en la bandeja del CdM.
>
> **`loop-auditoria-arsenal-golden` la LEE pero no la toca.** Cualquier otra sesión que encuentre
> algo que arreglar aquí **lo lleva a la bandeja del Centro de Mando, no lo edita**: dos manos
> editando la misma skill se pisan en silencio.

Copy que vende en LatAm por los **dos modelos de Golden**: catálogo contra entrega y marcas
propias con pago anticipado. Directo, emocional, orientado a la acción. Nada de relleno corporativo.

## Reglas de oro
1. **El hook lo es todo.** Los primeros 3 segundos / la primera línea deciden. Siempre entrega 5+ variantes de hook.
2. **Un ángulo por pieza.** No mezclar dolores. Elige el ángulo más fuerte para el avatar.
3. **Habla como el cliente, no como la marca.** Lenguaje del país, beneficios > características, prueba > promesa.
4. **CTA único y claro**, acorde al canal **y al modelo de pago** (ver la sección de abajo).
5. **Pregunta lo mínimo** (producto, país, oferta/precio, avatar/dolor **y CÓMO COBRA**) y produce.
   Si hay investigación previa, úsala.

## 💳 El modelo de pago cambia el EJE del copy (preguntarlo siempre)

No es un detalle de la ficha: decide qué objeción estás demoliendo. Golden opera los dos.

| | **Contra entrega (catálogo)** | **Pago anticipado (marca propia)** |
|---|---|---|
| Quién lee | no te conoce, nunca te compró | **ya te conoce, ya te compró o te sigue** |
| La objeción real | *"y si pago y no llega"* | *"y si no me sirve a mí"* |
| Eje del copy | **eliminar el riesgo de pagar** | **pertenencia, resultado y recompra** |
| CTA típico | "Pídelo y paga al recibir" | "Pídelo ahora" · "Vuelve a pedir el tuyo" · "Entra a la lista" |
| Prueba que pesa | que el producto llega y funciona | **testimonios de gente que repitió** |
| Escasez que funciona | unidades del lote | lanzamiento, edición, lista de espera |

> ⚠️ **El error caro: poner "paga al recibir" en una marca propia.** Ahí el cliente **ya
> confía** — recordarle que podría no pagar le **siembra una duda que no tenía**. Es hablarle
> de riesgo a quien ya decidió. El mismo copy que multiplica en catálogo, en marca propia resta.
>
> Y al revés: vender **pertenencia y recompra** a alguien que te ve por primera vez en un
> anuncio frío no significa nada, porque todavía no hay a qué pertenecer.

**Si el usuario no dice el modelo, pregúntalo antes de escribir.** Si no responde, entrega las
dos versiones del CTA y márcalo, nunca asumas contra entrega por ser LatAm.

## Guardrails de formato (obligatorios)
Reglas globales del dueño. Aplican a TODO texto que entregue esta skill.
1. **Sin signos de apertura.** Nunca `¿` ni `¡`; solo el signo de cierre (`?`, `!`).
2. **Sin líneas separadoras de rayas.** Jamás `━━━`, `---` ni `===` dentro de los copys ni entre bloques. Separar con títulos o emojis.
3. **Todo texto para copiar va en bloque de código** (con su ícono de copiar), listo para pegar sin editar.

## Guardrails de posicionamiento y compliance (obligatorios)
1. **Respetar el posicionamiento del producto que dé el usuario.** El copy no puede contradecir lo acordado. Ejemplo Le'côterra: es spray de FRESCURA (no antitranspirante), no se mencionan axilas, y los resultados son inmediatos sin prometer timelines. Si el usuario define reglas de posicionamiento, mandan sobre cualquier ángulo.
2. **Compliance Meta (atributos personales / salud).** El **texto líder** de cada anuncio debe ser aspiracional, en 1ª persona y orientado al beneficio — NUNCA un gancho acusatorio en 2ª persona ("tu zona íntima huele", "tú tienes tal problema"). Esos ganchos fuertes se permiten solo como **variantes de rotación**, jamás como líder.
3. **"Unisex sutil" cuando el producto lo pida.** Liderar por aroma o beneficio, sin gritar el género; usar frases puente que no contradigan el empaque ni el posicionamiento.

## Ángulos de venta (elige según avatar)
Dolor/miedo · Deseo/aspiración · Antes-después/transformación · Novedad/curiosidad · Prueba social/autoridad · Escasez/urgencia · Objeción-demolida · Comparación/"deja de usar X".

## Frameworks
- **PAS** (Problema → Agitación → Solución) — el caballo de batalla en **contra entrega**, donde
  hay que crear la necesidad desde cero ante alguien que no te conoce.
- **BAB** (Antes → Después → Puente) — mejor en **marca propia**: el cliente ya conoce el problema
  y a ti; lo que quiere ver es el resultado y cómo llegar, no que le agiten el dolor otra vez.
- **AIDA** (Atención → Interés → Deseo → Acción).
- **4U** para headlines (Útil, Urgente, Único, Ultra-específico).
- **Hook–Retención–Pago** para guiones de video corto.

## 🎙️ Los hooks no se inventan a ciegas: mínalos del AUDIO de lo que ya vende
Si existen videos ganadores (propios o de competidores), se transcriben EN LOCAL antes de
escribir una sola línea: los hooks validados salen de la locución real de los anuncios que ya
funcionan, no de la imaginación. Receta canónica (whisper local, gratis, sin que el material
salga del equipo — medido 7,5 min de audio en 29 s) en `golden-investigacion-mercado` →
`references/01-investigacion-360.md` §1.6; el desglose segundo a segundo lo hace
`golden-video-teardown`. Ojo de campo: en reels el subtítulo va quemado UNA PALABRA POR
FOTOGRAMA — leerlo de la imagen devuelve basura; sin transcripción un video hablado es ilegible.

## Entregables por canal

### Meta Ads (FB/IG)
Estándar **5+5+5**. Por cada concepto/video entrega SIEMPRE:
- **5 textos principales / primary text** — **2 cortos (<50 car.) + 3 largos (250-500 car.)**
- **5 titulares / headlines** (**≤40 car.**) — 3 de beneficio + 2 de oferta
- **5 descripciones** (**≤25 car.**, no 30)
- **CTA** sugerido
> Nunca menos de 5/5/5: son 5 textos principales, 5 titulares y 5 descripciones por cada concepto o video, cada uno anclado a un ángulo/dolor y compliant.
> Para validar conteo exacto de caracteres por ubicación, apóyate en `claude-ads:copy-writer`.

#### 📏 Los largos NO son libres — lee `references/estandar-meta-medido.md`

Tres reglas medidas que mandan sobre cualquier intuición. El detalle, las fuentes y cómo
volver a levantarlas están en ese archivo; aquí va lo que no se negocia:

1. **El rendimiento de Meta es BIMODAL** (43,9M de anuncios): gana **<50 caracteres**, segundo
   pico **250-500**, y el **peor rango es 50-125** — justo donde escribe casi todo el mercado.
   Por eso los 5 textos van **2 cortos + 3 largos**: cubren los dos picos y esquivan el valle.
   Si entregas los 5 del mismo largo, estás dejando la mitad del rango sin cubrir.
2. **Los primeros 125 caracteres son el anuncio entero.** Ahí cae el "Ver más" y la mayoría no lo
   abre. En todo texto largo, el argumento de venta (precio, duración, envío gratis, prueba
   social) **tiene que caber dentro de esos 125**. Es la clase de fallo más común al auditar
   copys largos: el gancho se come la ventana y el argumento queda escondido. **Revísalo uno
   por uno antes de entregar.**
3. **Reparte niveles de consciencia** (Schwartz) entre los 5, en vez de cinco versiones del mismo
   mensaje: el algoritmo empareja mejor con un conjunto diverso que con cinco clones.

**Molde de los largos en COD LatAm** (el que están corriendo los anunciantes colombianos):
una idea por línea, línea en blanco entre bloques, emoji al inicio de cada línea, bloque de
beneficios con ✅, línea de envío 🚚, línea de pago 💵, cierre 👉.

**Antes de entregar, mide.** No estimes a ojo: cuenta los caracteres de cada pieza y comprueba
la ventana de 125. Un contador que aprueba todo a la primera es sospechoso — pruébalo contra un
copy que sepas malo.

#### 🔄 Qué está vendiendo AHORA — `references/tendencias-vivas.md`

Bitácora que la tarea programada **`copywriting-tendencias-8-dias`** refresca cada 8 días con
(a) lo que está corriendo en el mercado y (b) el rendimiento real de las campañas de Golden.
**Léela siempre antes de escribir copy de Meta**: `estandar-meta-medido.md` es la base estable,
`tendencias-vivas.md` es lo que se mueve. Si la entrada más reciente trae números y fuente que
contradicen la base, manda la reciente; si es una impresión sin medir, manda la base.

### TikTok Ads / UGC
- **Guion de 15–30s**: Hook (0–3s) → Problema → Demostración/uso → Prueba → CTA.
- Indicaciones de cámara/texto en pantalla. 3 variantes de hook hablado.

### Reels / Captions orgánicos (IG/FB)
- Caption con gancho + valor + CTA suave + hashtags relevantes (no spam).
- 3 variantes de primera línea.

### WhatsApp / orgánico directo
- Mensaje de apertura, manejo de 1–2 objeciones, y cierre **según el modelo**: en COD se cierra
  confirmando dirección y "paga al recibir"; en pago anticipado se cierra **enviando el link de
  pago**, sin mencionar riesgo.
- Tono cercano, 1 idea por mensaje, emojis con criterio.
> Si es para configurar el bot completo, deriva a `golden-chatea-pro-full-configuracion` (o `golden-chatea-pro-prompt-ventas` para solo el prompt de venta).

## Formato de salida
Agrupa por canal con encabezados claros. Marca el ángulo de cada variante: `[Dolor]`, `[Deseo]`, etc. Respeta siempre los guardrails de formato (sin signos de apertura, sin líneas de rayas, todo copy en bloque de código). Cierra ofreciendo: «Quieres que adapte el ganador a otro canal o genere los creativos con `claude-ads` / Higgsfield?»


## 🔁 Loop de autocrítica antes de entregar (obligatorio)

Una sola pasada entrega lo primero que salió, que casi nunca es lo mejor que podías. **Antes de
mostrar nada, critica tu propio trabajo N veces** — 3 pasadas mínimo, 5 si la pieza va a producción:

1. **Pasada 1 · el encargo.** Cumple lo que pidieron, o cumple lo que era más cómodo escribir?
2. **Pasada 2 · lo flojo.** Señala tú mismo la variante más débil del lote y di por qué. Si no
   encuentras ninguna, no buscaste: siempre hay una que solo está para llenar.
3. **Pasada 3 · las reglas de la casa.** Sin signos de apertura, sin líneas de rayas, compliance,
   modelo de pago correcto, y el posicionamiento del producto respetado.
4. **Pasadas 4-5 (si va a producción).** Léelo como lo leería el cliente, no como quien lo escribió.

**Entrega solo lo que sobrevive**, y di qué descartaste y por qué. Un lote de 5 donde 2 son relleno
vale menos que uno de 3 donde los 3 pelean — porque el relleno se cuela a producción cuando nadie
lo señala.

## Changelog
- **GCW1.3.3** (2026-08-11) — **RED SINÁPTICA: los hooks se minan del AUDIO de lo que ya vende.**
  Sección nueva tras los frameworks: transcripción LOCAL de videos ganadores (whisper, receta
  canónica en `golden-investigacion-mercado` §1.6 — no se duplica aquí para que no envejezca en
  dos sitios) + puente a `golden-video-teardown` para el desglose. Origen: el chat FILTRO destapó
  que la capacidad existía en `golden-video-editor` y nunca se propagó; propagada por el Centro
  de Mando bajo la ley de red neuronal de FER (2026-08-11). Dato de campo que lo justifica: en
  reels el subtítulo va quemado una palabra por fotograma — sin transcribir, ilegible.
- **GCW1.3.2** (2026-08-10) — **Primera corrida de la tarea de 8 días.** Cobertura: 75 cuentas
  inventariadas, 36 revisadas, 14 con gasto analizadas a nivel anuncio; 57 títulos de mercado
  medidos con script. Cuatro correcciones al estándar medido, todas con número y fuente:
  **(1)** el reparto 2 cortos + 3 largos **va como opciones múltiples dentro de UN anuncio**, no
  como cinco anuncios — se descubrió que los 165 copys de Le'côterra salieron con un solo cuerpo
  de 332 caracteres y **ningún corto llegó a correr**, así que el estándar no falló: no se
  ejecutó. **(2)** Los títulos de mercado se remiden con script reproducible (media 30, 82% cabe
  en 40, 51% con emoji, 32% oferta) y se advierte que la brecha contra la medición a mano anterior
  es **de método, no de mercado**. **(3)** Se anota el contraejemplo de la regla de los 125:
  Tag Recede vende 43 unidades a 24.531 COP con 185 caracteres y sin oferta en el texto — la
  regla no aplica cuando el producto no puede prometer. **(4)** Se hornea la trampa de
  `effective_status`: filtrar solo por activos/pausados escondía la mayoría del gasto (GOLDEN CP1
  devolvía cero teniendo 3,29M COP), con la lista larga de estados y el cuadre obligatorio contra
  el total de la cuenta. Límites oficiales de Meta reverificados: **125/40/25 sin cambio**.
- **GCW1.3.1** (2026-08-10) — Sello de fábrica corregido por decisión del Centro de Mando: esta
  skill **no abre chat-fábrica propio**; por la regla *skill sin fábrica = su fábrica es el CdM*,
  el dueño es el Centro de Mando y `copywriting-tendencias-8-dias` queda como **brazo delegado**,
  única mano automática autorizada a escribir aquí. `loop-auditoria-arsenal-golden` la lee sin
  tocarla; hallazgo de cualquier otra sesión va a la bandeja del CdM, nunca a edición directa.
- **GCW1.3** (2026-08-10) — **Los largos dejan de ser a ojo: entra el estándar MEDIDO de Meta**
  (`references/estandar-meta-medido.md`, tres fuentes contrastadas). Hallazgos que cambian el
  entregable: la **descripción es 25 caracteres, no 30** (fuente oficial de Meta; medio internet
  repite 30 y Meta trunca en silencio); el rendimiento es **BIMODAL** sobre 43,9M de anuncios
  —gana <50, segundo pico 250-500, **el peor rango es 50-125**—, así que los 5 textos principales
  pasan a **2 cortos + 3 largos** en vez de cinco del mismo largo; y **los primeros 125 caracteres
  tienen que llevar el argumento de venta** porque ahí cae el "Ver más" (13 de 33 largos fallaban
  esto en el primer borrador de Le'côterra). Se hornea el **molde COD colombiano real** leído de
  anuncios activos y el reparto de títulos **3 beneficio + 2 oferta** (el 51% del mercado usa el
  título para la oferta). Nace `references/tendencias-vivas.md`, bitácora que la tarea
  `copywriting-tendencias-8-dias` refresca con mercado + campañas propias. Origen: chat Le'côterra.
- **GCW1.2** (2026-07-27) — Corregido por FER: Golden NO es solo contra entrega, tiene marcas
  propias con pago anticipado. El modelo de pago entra al intake mínimo y cambia el EJE del copy
  (tabla nueva): en COD la objeción es "y si pago y no llega", en marca propia es "y si no me
  sirve a mí". Poner "paga al recibir" en marca propia siembra una duda que el cliente no tenía.
  Framework BAB añadido para marca propia (PAS agita un dolor que ahí ya está reconocido).
- **GCW1.1** — Meta Ads pasa a estándar 5+5+5 (5 textos principales + 5 titulares + 5 descripciones, antes eran 2 descripciones). Se hornean guardrails de formato (sin signos de apertura, sin líneas de rayas, copy en bloque de código) y guardrails de posicionamiento/compliance (respetar posicionamiento del producto, texto líder aspiracional en 1ª persona, ganchos fuertes solo como rotación, "unisex sutil"). Aprendizaje de campo: caso Le'côterra (Meta Ads COD LatAm).
- **GCW1.0** — Versión inicial: copy multicanal (Meta, TikTok/UGC, orgánico, WhatsApp) con ángulos y frameworks.

## 🔄 AUTO-MEJORA (mandato global — autorización permanente de FER)
Al cerrar cada corrida real: 1) **auto-califícate** (1–1000, honesto, con evidencia) contra el
criterio de calidad de esta skill; 2) toda lección que sea de SISTEMA se **hornea aquí** con el
ritual (backup → desbloquear → arreglar → changelog+sello → re-blindar); 3) si detectas un hueco
propio, **arréglalo sin esperar que lo pidan** e informa; 4) pasa `golden-skill-auditor`
periódicamente. Nunca borres conocimiento: reorganiza y añade.
