#!/usr/bin/env python3
"""Lo que TODOS los generadores usan. UNA copia, importada.

POR QUE EXISTE, y la historia es la mejor prueba de que hacia falta:

Este expediente lleva tres rondas arreglando el mismo fallo — un telefono pintado como
"57" pelado cuando la persona no tiene telefono (llega por comentario de Facebook, no
por WhatsApp). Ronda 12: se arreglo en la tabla estrella. Ronda 13: se arreglo en las
otras tres... y quedaron OCHO sitios mas vivos, porque existia una SEGUNDA funcion
(`tel_de`) con el bug original. Y la funcion "unica" `contacto_de` estaba duplicada
byte a byte en los dos generadores, mientras `tel10` vivia en TRES copias.

LA CLASE: **la duplicacion no es un problema de estilo, es un problema de VERDAD**. Dos
copias de una funcion no son una funcion escrita dos veces: son dos funciones que hoy
coinciden y que en la primera correccion dejan de coincidir — y la que no se toca no
avisa. Por eso `denominador.py` existe (la regla de negocio) y por eso existe este
modulo (las funciones de pintar). Un arreglo aplicado a "la familia" solo vale si la
familia esta ENUMERADA en un sitio; si hay que acordarse de los miembros, se olvida uno.

COMO SE COMPRUEBA QUE NO VOLVIO: `prueba_escritura.py` corre un grep sobre los scripts y
exige CERO definiciones locales de estas funciones fuera de aqui. La regla que no se
puede comprobar sola se rompe sin ruido.

  from comun import contacto_de, tel10, miles, pesos, nom_de, huella_txt
"""
import os, re


def tel10(x):
    """Los ultimos 10 digitos. Colombia manda el mismo numero con y sin el 57 delante.

    Devuelve "" cuando no hay nada utilizable, y ese "" SIGNIFICA "sin telefono" — no
    es un fallo silencioso: quien lo recibe tiene que decidir que hacer con el, y en
    esta skill la decision es "esto no es WhatsApp, es un comentario publico".
    """
    return re.sub(r"\D", "", x or "")[-10:]


def contacto_de(e):
    """Como se contacta a esta persona. UNA definicion para TODAS las tablas.

    NORMALIZA, NO PREFIJA. Las dos familias traen el telefono en formatos distintos: el
    analisis lo da sin indicativo ("3000000001") y las decisiones ya lo dan con el
    ("573000000001"). Pegar "57" delante sin mirar producia "5757...". Se reduce a
    digitos, se toman los ultimos 10 y se pone UN indicativo.

    Acepta tanto un dict con "tel" como uno con "phone": las dos familias los nombran
    distinto y hacer que el llamador se acuerde de cual es cual es pedir el mismo fallo.
    """
    d = tel10(e.get("tel") or e.get("phone") or "")
    if not d:
        return "**comentario publico** · sin telefono"
    return "57" + d


def miles(x):
    """Los dos informes escriben los numeros igual.

    El 360 ponia 3.416 y el corto 3416: el mismo dato con dos grafias en dos PDF del
    mismo dia se lee como dos datos distintos.
    """
    return f"{int(x):,}".replace(",", ".")


def miles_seguro(x):
    """`miles()` cuando se puede, el valor tal cual cuando no. Para buscar en el texto."""
    try:
        return miles(x)
    except (TypeError, ValueError):
        return str(x)


def pesos(x):
    return f"${float(x or 0):,.0f}".replace(",", ".")


def nom_de(o):
    return f"{o.get('name','')} {o.get('surname','')}".strip()


def huella_txt(D, o):
    """El denominador son los pedidos CERRADOS, nunca el total.

    Un pedido en transito todavia no fracaso. Contarlo como fracaso pinta de rojo a
    quien apenas empieza — es exactamente el bug del "% de Entrega" de Chatea, que
    cuenta el transito como fallo y hace ver malos a clientes que no lo son.
    """
    t = tel10(o.get("phone"))
    h = (D.get("huellas") or {}).get(t)
    if not (h and h.get("found")):
        return "sin historial"
    lt = h["global_profile"]["lifetime_totals"]
    ent, dev = lt["delivered"], lt["returned"]
    cerradas = ent + dev
    transito = lt["orders"] - cerradas
    if cerradas == 0:
        return "primera compra" if not lt["orders"] else f"{transito} en camino, ninguno cerrado"
    txt = f"devuelve {100 * dev / cerradas:.0f}% de {cerradas} cerrados"
    return txt + (f", {transito} en camino" if transito else "")


def concuerda(n, singular, plural):
    """«1 fila no tiene» / «3 filas no tienen». La concordancia, como clase.

    Se arreglo una frase a mano y quedaron las demas. Una funcion no se olvida de
    ninguna.
    """
    return f"{miles(n)} {singular if n == 1 else plural}"


# ------------------------------------------------------------------------------
# LA POLITICA DEL PDF, UNA SOLA, PARA LOS DOS GENERADORES.
# Estaban en contradiccion: el informe corto se NEGABA si el archivo existia, y el 360
# ARCHIVABA lo que hubiera — incluido un PDF de otro chat. Y el comentario del 360 decia,
# literalmente, "lo ajeno no se pisa nunca" mientras el codigo movia lo ajeno. Un
# comentario correcto encima de un codigo que hace lo contrario es peor que no tenerlo:
# quien lo lee deja de mirar.
#
# COMO SE DISTINGUE LO PROPIO DE LO AJENO SIN ADIVINAR: cuando esta skill escribe un PDF
# deja al lado una marca (un archivo oculto con su nombre). Si la marca esta, el PDF es
# suyo y se archiva; si no esta, es de otro y NO SE TOCA. Sin marca no se supone nada.
MARCA_SUFIJO = ".golden-logistica"


def _marca_de(ruta_pdf):
    d, n = os.path.split(os.path.abspath(ruta_pdf))
    return os.path.join(d, "." + n + MARCA_SUFIJO)


def marcar_como_propio(ruta_pdf):
    """Deja la senal de autoria al lado del PDF. Se llama DESPUES de escribirlo.

    Aqui SI se usa `open` directo, y va explicado porque el banco lo cuenta: esto no
    lee ni produce un entregable, escribe una marca de control de tres lineas que se
    puede perder sin consecuencia. Pasarla por `escribir_texto` la apuntaria como
    insumo y ensuciaria el registro de la corrida con archivos que no son datos.
    """
    try:
        with open(_marca_de(ruta_pdf), "w", encoding="utf-8") as f:   # noqa: marca de control
            f.write("Lo escribio la skill golden-logistica-diaria. Si borras este archivo, "
                    "el PDF de al lado pasa a tratarse como AJENO y no se sobrescribira.\n")
    except OSError:
        pass          # no poder marcar no justifica no entregar el informe


def preparar_destino_pdf(ruta_pdf, carpeta_archivo):
    """Deja el sitio libre para escribir, sin destruir nada de nadie.

    Devuelve (se_puede, mensaje). Propio -> se archiva y se puede. Ajeno -> NO.
    """
    if not os.path.exists(ruta_pdf):
        return True, ""
    if not os.path.exists(_marca_de(ruta_pdf)):
        return False, (f"YA HAY UN PDF AHI Y NO LO ESCRIBIO ESTA SKILL: {ruta_pdf}\n"
                       "  No se archiva ni se sobrescribe un entregable ajeno: puede ser "
                       "el informe que otro chat dejo para hoy.\n"
                       "  Ya paso una vez. Elige otra ruta, o borra ese archivo a mano si "
                       "de verdad sobra.")
    import datetime as _dt, shutil
    os.makedirs(carpeta_archivo, exist_ok=True)
    base = os.path.basename(ruta_pdf).rsplit(".", 1)[0]
    fecha = _dt.datetime.fromtimestamp(os.path.getmtime(ruta_pdf)).strftime("%Y-%m-%d")
    destino = os.path.join(carpeta_archivo, f"{base}-{fecha}.pdf")
    n = 2
    while os.path.exists(destino):
        destino = os.path.join(carpeta_archivo, f"{base}-{fecha}-{n}.pdf")
        n += 1
    shutil.move(ruta_pdf, destino)
    try:
        os.unlink(_marca_de(ruta_pdf))
    except OSError:
        pass
    return True, f"  el informe anterior (propio) se archivo en {destino}"


# LAS CLAVES QUE ESTA SKILL ENTIENDE. UNA lista, porque el config es UNO.
# La primera version puso la lista dentro de cada generador y el aviso empezo a marcar
# como desconocidas las claves que lee el MOTOR (`mala_huella`, `ventaja_minima`...).
# Un aviso que grita en falso se ignora a los dos dias, y entonces ya no avisa de nada.
BANDERAS_CONOCIDAS = {
    # identidad y rutas
    "tienda", "dropi", "salida", "nombre_informe", "shop_id", "user_id", "flow_ns",
    # estados y seleccion
    "estados", "estados_accionables", "operativas", "origen", "oficina_solo",
    # economia y decision
    "margen", "factor_tienda", "apretado", "ventaja_minima", "mala_huella", "min_huella",
    "min_envios_muni", "min_cuota_muni",
    # fuentes de datos
    "torre", "retorno", "calibracion", "fletes", "huellas",
    # banderas de operacion
    "aceptar_cosecha_incompleta", "opciones_no_producto",
    # `pisar_pdf` ESTUVO AQUI SIN QUE NADIE LA LEYERA: documentada, listada como
    # conocida... y sin efecto. Es el caso exacto que `avisar_banderas` combate, y la
    # propia lista la eximia del aviso. Una lista de "claves validas" que incluye una
    # clave muerta convierte la compuerta en su contrario: certifica lo que no existe.
    # Se saca. Si alguien la pone, ahora SI se avisa de que no hace nada.
}


def avisar_banderas(cfg, ruta):
    """Nombra las claves que la skill no conoce. No mata: avisa.

    Una bandera mal escrita no hace nada y NO AVISA. El config de produccion llevaba
    `aceptar_cosecha_parcial` cuando el codigo lee `aceptar_cosecha_incompleta`: el
    dueño creia haber configurado algo que nunca estuvo configurado. Un config que
    acepta cualquier cosa en silencio miente sobre lo que esta puesto.
    """
    raras = sorted(k for k in cfg if not k.startswith("_") and k not in BANDERAS_CONOCIDAS)
    if raras:
        import sys as _s
        print(f"AVISO · {os.path.basename(ruta)} tiene claves que esta skill NO LEE: "
              + ", ".join(raras) + ". Si esperabas que hicieran algo, estan mal escritas.",
              file=_s.stderr)


# ------------------------------------------------------------------------------
# AQUI VIVIO `tabla()`, UN PARTIDOR DE TABLAS, Y DURO UNA RONDA.
#
# Lo escribi porque el PDF salio REQUIERE ARREGLO al incrustar las acciones, y razone
# que una tabla de 18 filas es un bloque atomico que no cabe. Lo puse, el PDF paso, y
# di la causa por probada. **El PDF paso porque el contenido cambio y la paginacion se
# corrio, no por el mecanismo que yo describi.**
#
# MEDIDO EL 2026-08-11 contra el `golden-pdf-check` de HOY: una tabla de 40 filas SIN
# partir da APROBADO en 2 paginas. `build_pdf` ya repite la cabecera al cortar y el
# auditor solo marca bloques monoespaciados. Retirado el partidor, los dos informes
# siguen dando APROBADO. La premisa era falsa.
#
# LA CLASE: **una justificacion escrita contra un sistema que ya cambio es una
# justificacion falsa que se lee como cierta.** El sintoma desaparecio, asi que nadie
# vuelve a mirar — y queda codigo cuyo comentario explica un mecanismo que no existe.
# De ahi la regla nueva: **toda afirmacion sobre un sistema EXTERNO lleva la fecha en
# que se midio**, igual que los pendientes. Sin fecha no se sabe si sigue siendo cierta.
#
# Y la segunda mitad, que es la que duele: el sintoma se fue y yo lo conte como arreglo.
# Que el problema desaparezca no prueba que la causa fuera la que uno dijo.
# ------------------------------------------------------------------------------


# ------------------------------------------------------------------------------
# CIRUGIA EN EL AIRE · un matcher que no coincide NO es "nada que hacer".
#
# EL CASO: un `re.sub` que quitaba una seccion duplicada del ensamble buscaba el titulo
# "Los que decides tu" y el titulo REAL era "🟡 Decides tu · 1". No coincidia con nada,
# devolvia el texto intacto — 9.597 caracteres antes y despues — y **yo reporte la
# seccion como eliminada**. El codigo no fallo: hizo exactamente lo que se le pidio, que
# era nada. Y "nada" y "lo que yo creia" se ven igual cuando no se cuenta.
#
# LA CLASE: **toda cirugia sobre texto asevera que encontro su objetivo.** Sustituir,
# borrar o recortar sin comprobar el numero de coincidencias es operar con los ojos
# cerrados y salir diciendo que sali bien. Vale para `re.sub`, para `replace` y para
# cualquier busqueda de la que dependa una afirmacion posterior.
def sustituir_exigiendo(patron, reemplazo, texto, que, flags=0, minimo=1):
    """`re.sub` que MUERE si no coincidio lo que se esperaba."""
    import re as _re
    nuevo, n = _re.subn(patron, reemplazo, texto, flags=flags)
    if n < minimo:
        raise SystemExit(
            f"CIRUGIA EN EL AIRE: {que}\n"
            f"  El patron no coincidio con nada (esperaba al menos {minimo}, hubo {n}).\n"
            f"  Patron: {patron!r}\n"
            "  Un matcher que no encuentra su objetivo no es 'nada que hacer': es una\n"
            "  operacion que se reporta como hecha y no se hizo. Se corrige el patron o\n"
            "  se corrige la expectativa, pero no se sigue en silencio.")
    return nuevo


def _sin_tildes(s):
    import unicodedata as _u
    return "".join(c for c in _u.normalize("NFD", str(s or "").lower())
                   if _u.category(c) != "Mn")


def _como_suena(s):
    """El nombre de la transportadora como lo escribe quien lo dicta por WhatsApp.

    MEDIDO sobre las 12 direcciones de Dolce que hablan de recoger: dos de ellas — una
    de cada seis — traen el nombre roto, y no de cualquier forma:
      · «Oficina de Inter rapidisimo»  -> partido por un espacio
      · «Oficina interrapidicimo ...»  -> escrito como suena (c por s)
    Comparar la cadena tal cual las dejaba en DUDOSO, que es seguro pero pobre: son
    puntos de recogida perfectamente identificables. Se quitan los separadores y se
    funden c/z en s, que es la confusion ortografica del castellano de aca. La ventana
    donde se busca sigue siendo de 40 caracteres pegados a la palabra que dispara, asi
    que el pliegue no puede casar con cualquier cosa del resto de la direccion.
    """
    s = _sin_tildes(s)
    s = re.sub(r"[^a-z0-9]", "", s)
    return s.replace("z", "s").replace("c", "s")


# Las palabras que DISPARAN la sospecha de recogida en punto. Ninguna decide sola.
_GATILLO = re.compile(r"\b(oficina|sucursal|agencia|punto|reclam\w*|recog\w*|recoj\w*)\b")
# Lo que, PEGADO al gatillo, dice que NO es un punto de recogida sino la direccion del
# cliente: un numero de oficina, un piso, una torre, un edificio.
_ES_DIRECCION = re.compile(
    r"^[\s.,#-]*(?:n[or]?[.\s]*)?\d|^[\s.,#-]*(?:piso|torre|apto|apartamento|bloque|"
    r"local|interior|edificio|conjunto|barrio|casa)\b")


def pide_oficina(direccion, transportadoras=()):
    """TRES ESTADOS: «punto», «direccion» o «dudoso». Nunca dos.

    POR QUE EXISTE, y el caso es de FER via LOGISTICA DOLCE (2026-08-11): el detector
    viejo era `re.search(r"oficina|reclame", dir)` — la palabra suelta, sin mirar nada
    mas. Con eso:
      · «Oficina InterRapidisimo» -> recogida en punto. CORRECTO.
      · «oficina 303 Edificio Central» -> recogida en punto. **FALSO POSITIVO MEDIDO**, y
        era la direccion de trabajo de una clienta de Pereira.
    La palabra no distingue. **Lo que distingue es lo que va PEGADO a la palabra**: si al
    lado esta el nombre de una transportadora, es un punto de esa transportadora; si al
    lado hay un numero, un piso o una torre, es donde vive o trabaja el cliente.

    Y el tercer estado NO es un lujo. Una direccion que dice «reclamar en oficina» a
    secas no es ninguna de las dos cosas: es una que **nadie ha medido**. Devolverla como
    «direccion» seria darle permiso al motor para cambiarle la transportadora, y ese
    cambio, si de verdad era un punto, no es un ahorro: es una devolucion. Lo dudoso se
    devuelve dudoso y el informe lo dice.

    `transportadoras` son los nombres reales de la cuenta (config «operativas» + la que
    el pedido ya trae). Sin lista no se puede afirmar «punto»: se devuelve «dudoso», que
    es lo que de verdad se sabe.
    """
    d = _sin_tildes(direccion)
    if not d.strip():
        return "direccion", "no dice nada de recoger"
    nombres = [(_como_suena(t), t) for t in (transportadoras or []) if str(t).strip()]
    razones_dudoso = []
    for m in _GATILLO.finditer(d):
        ventana = d[m.end():m.end() + 40]
        antes = d[max(0, m.start() - 25):m.start()]
        # El pliegue fonetico se usa SOLO para reconocer la transportadora. La prueba de
        # «esto es una direccion» necesita la ventana CRUDA: al plegarla, «oficina piso
        # 4» se volvia «ofisinapiso4» y el patron, que se apoya en el espacio y en el
        # limite de palabra, dejaba de casar. Lo midio el banco en la misma corrida.
        for plano, original in nombres:
            if plano and (plano in _como_suena(ventana) or plano in _como_suena(antes)):
                return "punto", f"dice «{m.group(1)}» junto a {original}"
        if _ES_DIRECCION.match(ventana):
            continue          # «oficina 303», «oficina piso 4»: es donde esta el cliente
        razones_dudoso.append(m.group(1))
    if razones_dudoso:
        return "dudoso", (f"dice «{razones_dudoso[0]}» pero no nombra transportadora "
                          "ni numero: no se puede saber si es punto de recogida")
    return "direccion", "no pide recogida en punto"


# El paquete ya se movio: aqui la guia ya no se cambia, solo se llama.
YA_NO_SE_REASIGNA_POR_DEFECTO = ("EN REPARTO", "EN TERMINAL DESTINO", "EN BODEGA DESTINO",
                                 "BODEGA DESTINO", "EN RUTA", "EN CAMINO",
                                 "INTENTO DE ENTREGA", "EN REEXPEDICION")


def guias_por_corregir(decisiones, ya_no_se_reasigna=None):
    """Los pedidos CON GUIA que todavia se alcanzan a corregir, y lo que hay en juego.

    UNA DEFINICION, DOS CONSUMIDORES, y la razon es un fallo de esta misma ronda: al
    escribir el Paso 1 en los dos generadores lo defini dos veces — el de acciones por
    ESTADO y el de 360 por CAMPO `guia` — y la misma seccion del mismo dia salio con
    **13 pedidos y $36.222 en un papel y 21 y $43.725 en el otro**. Las dos cuentas eran
    ciertas y contaban cosas distintas; para el que las lee eso no es matiz, es que uno
    de los dos documentos miente. Es la falta que este expediente ya pago una vez con
    los dos denominadores de la conversion, asi que la definicion vive aqui sola.

    QUE CUENTA COMO GUIA POR CORREGIR: **tiene guia** (el hecho: ya se genero) **y el
    paquete no se ha movido** (por eso todavia se cambia) **y hace falta hacer algo**.
    El estado no define la guia: la guia la define el campo `guia`. El estado define si
    la ventana sigue abierta.

    Devuelve (lista ordenada por valor, plata en juego).
    """
    cerrados = set(ya_no_se_reasigna or YA_NO_SE_REASIGNA_POR_DEFECTO)
    fuera = []
    for d in decisiones or []:
        if not isinstance(d, dict):
            continue
        if not str(d.get("guia") or "").strip():
            continue
        if str(d.get("status") or "").upper().strip() in cerrados:
            continue
        if d.get("rec") not in ("CAMBIAR", "ASIGNAR", "SIN COBERTURA"):
            continue
        fuera.append(d)
    plata = 0
    for d in fuera:
        e = d.get("elegida")
        act = [c for c in (d.get("cands") or []) if c.get("t") == d.get("actual")]
        if e and act:
            plata += max(0, act[0]["costo"] - e["costo"])
    fuera.sort(key=lambda z: -float(z.get("total") or 0))
    return fuera, plata


def exigir_presente(texto, aguja, que, minimo=1):
    """La otra mitad: una BUSQUEDA de la que depende una afirmacion tambien asevera."""
    n = texto.count(aguja)
    if n < minimo:
        raise SystemExit(
            f"NO ESTA LO QUE SE BUSCABA: {que}\n"
            f"  «{aguja}» aparece {n} veces y se esperaban al menos {minimo}.")
    return n
